import pandas as pd 
from pathlib import Path



home_location = Path.cwd() / 'after_augment' 

train_csv = home_location / "train.csv"
test_csv = home_location / "test.csv"
validation_csv = home_location / "validation.csv"


train_data = pd.read_csv(train_csv)
test_data = pd.read_csv(test_csv)
validation_data = pd.read_csv(validation_csv)

train_data['class']= train_data['class'].map({'grade':1,"non-grade":2})
test_data['class']= test_data['class'].map({'grade':1,"non-grade":2})
validation_data['class']= validation_data['class'].map({'grade':1,"non-grade":2})


train = train_data.iloc[:][['class','filename']] 
test = test_data.iloc[:][['class','filename']]
validation = validation_data.iloc[:][['class','filename']]


train_labels = {train_data.iloc[i]['filename']:train_data.iloc[i]['class']  for i in range(len(train)) }
test_labels =  {test_data.iloc[i]['filename']:test_data.iloc[i]['class']  for i in range(len(test)) }
validation_labels =  {validation_data.iloc[i]['filename']:validation_data.iloc[i]['class']  for i in range(len(validation)) }

def area(s):
    return (s[3]-s[1]) * (s[2] - s[0])

train_boxes = {train_data.iloc[i]['filename']:list(train_data.iloc[i][4:])  for i in range(len(train)) }
test_boxes =  {test_data.iloc[i]['filename']:list(test_data.iloc[i][4:])  for i in range(len(test)) }
validation_boxes =  {validation_data.iloc[i]['filename']:list(validation_data.iloc[i][4:] ) for i in range(len(validation)) }


train_area = {train_data.iloc[i]['filename']:int(list(map(area,[list(train_data.iloc[i][4:])]))[0]) for i in range(len(train)) }
test_area =  {test_data.iloc[i]['filename']:int(list(map(area,[list(test_data.iloc[i][4:])]))[0])  for i in range(len(test)) }
validation_area =  {validation_data.iloc[i]['filename']:int(list(map(area,[list(validation_data.iloc[i][4:])]) )[0]) for i in range(len(validation)) }



partion = {"train":{'train_names':train_data.iloc[:]['filename'].values ,'labels':train_labels,'boxes':train_boxes,'area':train_area},
           "test":{'test_names':test_data.iloc[:]['filename'].values ,'labels':test_labels,'boxes':test_boxes,'area':test_area},
           "validation":{'validation_names':validation_data.iloc[:]['filename'].values ,'labels':validation_labels,'boxes':validation_boxes,'area':validation_area}}

           

def id_labels( x ):

    return partion[x]