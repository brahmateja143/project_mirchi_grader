import argparse 
import os 
import shutil 
from glob import glob
import random

import numpy as np 

from tqdm import tqdm



parser = argparse.ArgumentParser()
parser.add_argument("--indir",'-i',type=str,help="enter the input folder location")
parser.add_argument("--outdir",'-o',default = "./after_split",type = str ,help = "enter the output dir location")
parser.add_argument("--size",'-s',default= 224,type = int ,help ="output image is resized to given size")

args = parser.parse_args()

assert  os.path.isdir(args.indir) , "could not find the dir at {}".format(args.indir)

if not os.path.exists(args.outdir):
    print("creating..............")
    os.mkdir(args.outdir)
else:
    print("Warning,Overriding existing output folder {}".format(args.outdir))

    shutil.rmtree(args.outdir)
    os.mkdir(args.outdir)

os.mkdir(os.path.join(args.outdir,"train"))   

os.mkdir(os.path.join(args.outdir,"validation"))  

os.mkdir(os.path.join(args.outdir,"test")) 

path_train =  os.path.join(args.outdir,"train")

path_test = os.path.join(args.outdir,"test")

path_val = os.path.join(args.outdir,"validation")



foldername = [file.path for file in os.scandir(args.indir) if file.is_dir()]

print(foldername)

classes = 0

for i in range(len(foldername)):
    
	file_names = glob(os.path.join(foldername[i],"*.jpg"))
    
	file_names.sort()

	random.shuffle(file_names)

	file_names = np.array(file_names)

	train ,test ,validation = np.split(file_names,[int(0.6*len(file_names)),int(0.9*len(file_names))])
	print(classes)
	with tqdm(total = len(train)) as pbar :

		for file in train:

			name = file.split("/")[-1]

			shutil.copy2(str(file),os.path.join(path_train,name))
			
			#print(path_train)

			pbar.update(1)
	with tqdm(total = len(test)) as pbar :		

		for file in test :

			name = file.split("/")[-1]

			shutil.copy2(str(file),os.path.join(path_test,name))

			pbar.update(1)

	with tqdm(total = len(validation)) as pbar :
		for file in validation :

			name = file.split("/")[-1]

			shutil.copy2(str(file),os.path.join(path_val,name))

			pbar.update(1)	

	classes	  = classes + 1 
    	
