import argparse 
from PIL import Image 
from pathlib import Path 
import shutil
import cv2 
import numpy as np 
import imgaug.augmenters as iaa 
import imgaug as ia
import pandas as pd 
import matplotlib.pyplot as plt
from collections import defaultdict
import os

parser = argparse.ArgumentParser()
parser.add_argument('-i','--input',default = 'after_split', help = "path location of images to be after splitting")
parser.add_argument('-o','--output',default = 'after_augment',help = 'path location to save images after after augmenting')
parser.add_argument('-c','--csv_file',default = 'out_csv_folder',help = 'path location of csv files of dataset')
args = parser.parse_args()

home_location = Path.cwd()
input_location = home_location /args.input
assert input_location.exists(),"Input folder location need to be check once more"
output_location = home_location / args.output
train_path = output_location / 'train' 
test_path = output_location / 'test'
val_path = output_location / 'validation'
if not  output_location.exists():
    print("..................Creating output file  ...............")
    output_location.mkdir()
    train_path.mkdir()
    test_path.mkdir()
    val_path.mkdir()
else:
    print("Warning:.....Removing existing folder..................")
    shutil.rmtree(output_location)
    print("..................Creating output file  ...............")
    output_location.mkdir()
    train_path.mkdir()
    test_path.mkdir()
    val_path.mkdir()

seq_1 = iaa.Sequential([
    iaa.Fliplr(1),
iaa.GaussianBlur(sigma = (0,1.1))])
seq_2 = iaa.Sequential([
    iaa.Fliplr(1),
    iaa.Multiply((1.2,1.5))
])
seq_3 = iaa.Sequential([
    iaa.Fliplr(1),
    iaa.Multiply((1.2,1.5)),
    iaa.Affine(translate_px={"x": 40, "y": 30},
        scale=(0.5, 0.7))
])
seq_4 = iaa.Sequential([
    #iaa.Multiply((1.2,1.5)),
    iaa.AdditiveGaussianNoise()

])
seq_5 = iaa.Sequential([
    iaa.Fliplr(1),
    iaa.AdditiveGaussianNoise()
])
seq_6 = iaa.Sequential([
    iaa.Fliplr(1),
    iaa.AdditiveLaplaceNoise()
])
seq_7 = iaa.Sequential([
    iaa.Fliplr(1),
    iaa.AdditiveGaussianNoise(),
    iaa.Affine(
        scale=(0.8, 0.8))
])
seq_8 = iaa.Sequential([
    iaa.Fliplr(1),
    iaa.AdditiveLaplaceNoise(),
    iaa.Affine(
        scale=(0.8, 0.8))
])
seq_9 = iaa.Sequential([
    iaa.CenterCropToSquare()
])
seq_10 = iaa.Sequential([
    iaa.CenterCropToSquare(),
    iaa.Affine(
        scale=(0.8, 0.8))
    
])
seq_11 = iaa.Sequential([
    iaa.CenterPadToSquare(),
    iaa.GammaContrast()
    
])
seq_12 = iaa.Sequential([
    iaa.GammaContrast(),
    iaa.HorizontalFlip()
    
])
seq_13 = iaa.Sequential([
 iaa.LogContrast()
    
])
seq_14 = iaa.Sequential([
    iaa.MotionBlur(),
    iaa.ShearX(10)
])
seq_15 = iaa.Sequential([
 iaa.LogContrast(),
 iaa.ShearX(10)
    
])
seq_16 = iaa.Sequential([
 iaa.ShearY(20)
    
])
seq_17 = iaa.Sequential([
 iaa.Fliplr(1),
 iaa.ShearY(20)
    
])
seq_18 = iaa.Sequential([
 iaa.Rotate((-10,10))
    
])
seq_19 = iaa.Sequential([
 iaa.Rotate((-10,10)),
 iaa.AdditiveGaussianNoise()
    
])
seq_20 = iaa.Sequential([
 iaa.Fliplr(),
 iaa.Rotate((-10,10)),

    
])

class aug_csv():
	home_location = Path.cwd()
	data_augment = defaultdict(list) 
	count = 0
	def __init__(self,img,box,img_path,trans,out_path):
		self.img = Image.fromarray(img)
		self.box = box
		self.img_path = img_path
		self.trans = trans 
		self.out_path = out_path
	def update(self):
		print(self.count)
		self.img.save(self.out_path / (str(len(self.data_augment['filename']))+"_"+self.img_path.stem + '_'+self.trans +self.img_path.suffix ))
		x,y = self.box[0]
		x2,y2 = self.box[1]
		label = self.box.label
		print(str(self.count)+img_path.stem + '_'+self.trans +img_path.suffix)
		self.data_augment['filename'].append(str(len(self.data_augment['filename']))+'_'+img_path.stem + '_'+self.trans +img_path.suffix)
		self.data_augment['width'].append(images[i].shape[1])
		self.data_augment['height'].append(images[i].shape[0])
		self.data_augment['class'].append(label)
		self.data_augment['xmin'].append(int(x))
		self.data_augment['ymin'].append(int(y))
		self.data_augment['xmax'].append(int(x2))
		self.data_augment['ymax'].append(int(y2))
		
		self.count += 1
		
	def clear(self):
   		for key in self.data_augment.keys():
   			self.data_augment[key][:] = []
   		self.count = 0
	

for i in (home_location /  args.input).iterdir():
	aug_path_folder = i.stem
	image_names = [i.name for i in list(i.iterdir())]

	out_path = home_location /'after_augment'/i.stem
	data = pd.read_csv(os.path.join(args.csv_file, aug_path_folder+".csv"),index_col=0)
	aug_path = i 
	list_box = [] 
	for i in range(len(data)):
	    row = image_names[i] 
	    x = data.loc[row][3:]
	    print(x)
	    xmin,ymin,xmax,ymax = x 
	    label = data.loc[row][2]
	    print(xmin,ymin,xmax,ymax)
	    list_box.append(ia.BoundingBox(xmin,ymin,xmax,ymax,label = label))
    
	images = []
	for i in aug_path.iterdir():
	    img = np.array(Image.open(i))
	    images.append(img)
	for i,img_path in enumerate(aug_path.iterdir()):
	    trans_1,box_1 = seq_1(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_1[0],box_1,img_path,'trans_1',out_path)
	    out.update()
	    trans_2,box_2 = seq_2(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_2[0],box_2,img_path,'trans_2',out_path)
	    out.update()
	    trans_3,box_3 = seq_3(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_3[0],box_3,img_path,'trans_3',out_path)
	    out.update()
	    trans_4,box_4 = seq_4(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_4[0],box_4,img_path,'trans_4',out_path)
	    out.update()
	    trans_5,box_5 = seq_5(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_5[0],box_5,img_path,'trans_5',out_path)
	    out.update()
	    trans_6,box_6 = seq_6(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_6[0],box_6,img_path,'trans_6',out_path)
	    out.update()
	    trans_7,box_7 = seq_7(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_7[0],box_7,img_path,'trans_7',out_path)
	    out.update()
	    trans_8,box_8 = seq_8(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_8[0],box_8,img_path,'trans_8',out_path)
	    out.update()
	    trans_9,box_9 = seq_9(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_9[0],box_9,img_path,'trans_9',out_path)
	    out.update()
	    trans_10,box_10 = seq_10(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_10[0],box_10,img_path,'trans_10',out_path)
	    out.update()
	    trans_11,box_11 = seq_11(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_11[0],box_11,img_path,'trans_11',out_path)
	    out.update()
	    trans_12,box_12 = seq_12(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_12[0],box_12,img_path,'trans_12',out_path)
	    out.update()
	    trans_13,box_13 = seq_13(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_13[0],box_13,img_path,'trans_13',out_path)
	    out.update()
	    trans_14,box_14 = seq_14(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_14[0],box_14,img_path,'trans_14',out_path)
	    out.update()
	    trans_15,box_15 = seq_15(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_15[0],box_15,img_path,'trans_15',out_path)
	    out.update()
	    trans_16,box_16 = seq_16(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_16[0],box_16,img_path,'trans_16',out_path)
	    out.update()
	    trans_17,box_17 = seq_17(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_17[0],box_17,img_path,'trans_17',out_path)
	    out.update()
	    trans_18,box_18 = seq_18(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_18[0],box_18,img_path,'trans_18',out_path)
	    out.update()
	    trans_19,box_19 = seq_19(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_19[0],box_19,img_path,'trans_19',out_path)
	    out.update()
	    trans_20,box_20 = seq_20(images = [images[i]],bounding_boxes = list_box[i])
	    out = aug_csv(trans_20[0],box_20,img_path,'trans_20',out_path)
	    out.update()
	df = pd.DataFrame(aug_csv.data_augment)
	print(os.path.join(args.output ,aug_path_folder+".csv"))
	df.to_csv(os.path.join(args.output ,aug_path_folder+".csv"),index=False)
	print(f"sucessflly completed augumenting {aug_path_folder}")
	out.clear()
    


