from torch.utils import data
import torch
from torchvision import transforms
from PIL import  Image
from torch.utils.data import DataLoader

from data_prep import id_labels
from utils import location



class CustomDataset(Dataset):
    def __init__(self,imgs_path , data_dict,transforms = None):
        self.imgs = data_dict['train_names']
        self.labels = data_dict['labels']
        self.boxes = data_dict['boxes']
        self.areas = data_dict['area']
        self.imgs_path = imgs_path
        self.transforms = transforms
    def __getitem__(self,idx):
        
        img = np.array(Image.open(self.imgs_path / self.imgs[idx]).convert('RGB'))
        img = img.transpose([2,0,1])
        
        image_id = torch.tensor(idx)
        
        box = torch.as_tensor(self.boxes[self.imgs[idx]], dtype=torch.float32)
        
        label = torch.tensor(self.labels[self.imgs[idx]])
        
        area = torch.tensor(self.areas[self.imgs[idx]])
        
        iscrowd = torch.zeros((1,), dtype=torch.int64)
        
        target = {}
        target["boxes"] = box
        target["labels"] = label
        target["image_id"] = image_id
        target["area"] = area
        target["iscrowd"] = iscrowd
        
        if self.transforms is not None:
            img, target = self.transforms(img, target)

        return img, target
    def __len__(self):
            
        return len(self.imgs)


data_loader = {}
def load_datasets(names: list ) -> dict:
    '''
    names: list of strings specifying which data to load 
            example : ['train','test','validation']
    return: Dictionary contains dataloaders
    
    '''
    for name in names:
        
      data_loader[name] = DataLoader(CustomDataset(location(name),id_labels(name)),batch_size=32,shuffle=True,drop_last=True)
    
    return data_loader