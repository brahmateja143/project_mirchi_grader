
from pathlib import Path


img_paths = {}
home_location= Path.cwd()
img_paths['train'] = home_location / 'after_augment' / 'train'
img_paths['test'] = home_location / 'after_augment' / 'test'
img_paths['validation'] = home_location / 'after_augment' / 'validation'




def save_ckpt(state, is_best ,ckpt_path, best_model_path):
    
    '''
    
    state:dict 
                    -> epoch 
                    -> valid_loss_min 
                    -> state of the model 
                    -> state of the optimizer
        is_best: Boolean
        
        ckpt_path: path location to save the model and optimizer parameters and others
                    and others parameters to resume training.
                    
        best_model_path:location to save  best model. 
        
        
        '''
    
    latest_model = ckpt_path / 'latest_model.pth.tar'
    
    best_model_path = best_model_path / 'best_model.pth.tar'
    
    torch.save(state,latest_model)
    
    if is_best:
        
        shutil.copyfile(latest_model,best_model_path)



def load_ckpt(ckpt_path , model , optimizer):
    
    '''
    
    ckpt_path: location that contains pytorch .pth file 
    
    model : model to intialize the parameters
    
    optimizer:optimizer to intialize
    
    '''
    
    assert not ckpt_path.exists ,'checkpoint does not exists check once again' 

    checkpoint = torch.load(ckpt_path)
    
    model.load_state_dict(checkpoint['model'])
    
    optimizer.load_state_dict(checkpoint['optimizier'])
    
    valid_loss_min = checkpoint['valid_loss_min']
    
    return model ,optimizer ,checkpoint['epoch'] , valid_loss_min.item()


def location(label :'str') -> 'path location':

    
    return img_paths[label]





    